function [C dimen] = cropCamera(C)
% function [C dimen] = cropCamera(C)
%   C(1,3) = C(1,3)-40;
%   C(2,3) = C(2,3)-45;
%   dimen = [425 560];

% AUTORIGHTS

  C(1,3) = C(1,3)-40;
  C(2,3) = C(2,3)-45;
  dimen = [425 560];
end
