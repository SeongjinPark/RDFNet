function I = getImage(imName, typ)
% function I = getImage(imName, typ)
%  Input:
%   typ   one of ['images', 'depth']

% AUTORIGHTS

%   paths = benchmarkPaths();
%   dataDir = '/media/sj/Data/nyud2';
  dataDir = '/media/sj/Data/nyud2/rawdata/kitchens_part1/kitchen_0001b/';
  I = imread(fullfile(dataDir, typ, strcat(imName, '.png')));
%     I = imread(fullfile('demo-data',typ,strcat(imName, '.png')));
end
