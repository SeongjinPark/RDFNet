addpath(genpath('rgbdutils'));
C = cropCamera(getCameraParam('color'));
outDir='/media/sj/Data/nyud2/';
% outDir='/media/sj/Data/nyud2/rawdata/kitchens_part1/kitchen_0001b/hha/';

D = [];
RD = [];
imlist = dir('/media/sj/Data/nyud2/*.png');
sumv =0;
for i = 1:numel(imlist)
    imname = imlist(i).name(1:end-4);

    [HHA,pc2,HHB,AHB] = saveHHA(imname, C, outDir, D, RD,'/media/sj/Data/nyud2/');
    sprintf('processing %d',i)
%     imwrite(uint8(HHA),fullfile('/media/sj/Data/nyud2/hha_org_missing',[imname '.png']));
    figure(1);imshow(uint8(HHA(:,:,3)))
%     
%     figure(3);imshow(uint8(AHB))
%     figure(4);imagesc(AHB(:,:,1))
%     imwrite(uint8(AHB),fullfile('/media/sj/Data/nyud2/ahb',[imname '.png']));
    
% 
%     max(max(HHA(:,:,3)))
%     min(min(HHA(:,:,3)))
%     
%     T = floor((HHA(:,:,3)-38)./12);
%     figure(7);imagesc(T);
%     T = T+1;
%     min(min(T))
%     TT = floor((HHB(:,:,3)-38)./12);
%     figure(8);imagesc(TT);
%     TT = TT+1;
%     
%     val = izigzag([0:255],16,16)
%     ttt = val(sub2ind(size(val),TT,T));
%     max(max(ttt))
%     min(min(ttt))
%     figure(9);imagesc(ttt)    
%     HHC = HHA;
%     HHC(:,:,3)= ttt;
% % %     
% %     T = HHA(:,:,3)/2+HHB(:,:,3)/2;
% %     figure(6);imagesc(HHA(:,:,3)/2+HHB(:,:,3)/2)     
% %     
% %     HHT = HHA;
% %     HHT(:,:,3)=T;
    figure(8);imshow(HHA);
%     figure(9);imshow(HHB);
%     sumv = sumv+sum(sum(ttt))
%     numel(imlist)
pause
    imwrite(uint8(HHA),fullfile('/media/sj/Data/suncg_sampled/hha',[imname(1:end-3) '_hha.png']));
%     pause
%     pause
end