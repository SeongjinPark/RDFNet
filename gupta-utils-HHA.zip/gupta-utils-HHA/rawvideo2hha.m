%% %% depth to hha : process raw video sequences to generate hha 
% input: rgb, rawdepth, cameraparam
% output: projected & filled depthmap, hha
addpath(genpath('rgbdutils'));
addpath(genpath('/media/sj/Data/nyud2/toolbox'));
%% save synched_projected_filled_frames

% The directory where you extracted the raw dataset.
datasetDir = '/media/sj/Data/nyud2/rawdata/';

% The name of the scene to demo.
files = dir('/media/sj/Data/nyud2/rawdata');
dirFlags = [files.isdir];
% Extract only those that are directories.
scenelist = files(dirFlags);


for ww = 9:length(scenelist)
scenenum = dir(fullfile(datasetDir,scenelist(ww).name));
for ee = 3:length(scenenum)
%     try
sceneName = [scenelist(ww).name '/' scenenum(ee).name]
% sceneName = 'bathrooms_part1/bathroom_0007';

% The absolute directory of the 
sceneDir = fullfile(datasetDir, sceneName);


% if(exist(fullfile(sceneDir,sceneName,'hha'),'dir'))
%     disp('continue')
%     continue;
% end
save_rgb_dir = fullfile(sceneDir,'images');
save_depth_dir = fullfile(sceneDir,'depth');
save_rawdepth_dir = fullfile(sceneDir,'rawdepth');

rmdir(save_rgb_dir,'s');
mkdir(save_rgb_dir);

rmdir(save_depth_dir,'s');
mkdir(save_depth_dir);

rmdir(save_rawdepth_dir,'s');
mkdir(save_rawdepth_dir);

% Reads the list of frames.
frameList = get_synched_frames(sceneDir);

fp = fopen(fullfile(sceneDir,'test.txt'),'w');

% Displays each pair of synchronized RGB and Depth frames.
for ii = 1 : 5 : numel(frameList)-5
    numel(frameList)
    ii
    
%     try
  imgRgb = imread([sceneDir '/' frameList(ii).rawRgbFilename]);
  imgDepthRaw = swapbytes(imread([sceneDir '/' frameList(ii).rawDepthFilename]));
  imshow(imgDepthRaw)
  [sceneDir '/' frameList(ii).rawDepthFilename]
%   figure(1);
%   % Show the RGB image.
%   subplot(1,3,1);
%   imagesc(imgRgb);
%   axis off;
%   axis equal;
%   title('RGB');
%   
%   % Show the Raw Depth image.
%   subplot(1,3,2);
%   imagesc(imgDepthRaw);
%   axis off; 
%   axis equal;
%   title('Raw Depth');
%   caxis([800 1100]);
%   
%   % Show the projected depth image.
  imgDepthProj = project_depth_map(imgDepthRaw, imgRgb);
%   subplot(1,3,3);
%   imagesc(imgDepthProj);
%   axis off;
%   axis equal;
%   title('Projected Depth');
%   
%   
%   pause(0.01);
  
  imgRgb = crop_image(imgRgb);
  imgDepthAbs = crop_image(imgDepthProj);
  
  imgDepthFilled = fill_depth_cross_bf(imgRgb, double(imgDepthAbs));
%   pause
%   figure(2);
%   subplot(1,3,1); imagesc(imgRgb);
%   subplot(1,3,2); imagesc(imgDepthAbs);
%   subplot(1,3,3); imagesc(imgDepthFilled);
%   pause(0.01);
  imwrite(imgRgb,fullfile(save_rgb_dir,sprintf('%d.png',ii)));
  imwrite(uint16(imgDepthFilled*1000),fullfile(save_depth_dir,sprintf('%d.png',ii)));
  imwrite(uint16(imgDepthAbs*1000),fullfile(save_rawdepth_dir,sprintf('%d.png',ii)));
    fprintf(fp,'%d\n',ii);
%     catch
%     end
    
%   pause
end

%% compute HHA from rgbd
C = cropCamera(getCameraParam('color'));
% outDir='/media/sj/Data/nyud2/hha/';
outDir=fullfile(sceneDir,'hha');
if(~exist(outDir,'dir'))
    mkdir(outDir);
end

D = [];
RD = [];
imlist = dir(fullfile(sceneDir,'images','*.png'));
% try
for i = 1:numel(imlist)
    imname = imlist(i).name(1:end-4);
    HHA = saveHHA(imname, C, outDir, D, RD,sceneDir);
    sprintf('processing %d',i)
    %figure;imshow(HHA(:,:,1))
    % figure;imshow(HHA(:,:,2))
    % figure;imagesc(HHA(:,:,3))
end
% catch
% end
%     pause
end
end

