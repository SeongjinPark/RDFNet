    void help() {
    }

    Image load(string filename) {
        panic("This file type not implemented in this build\n");
        Image im;
        return im;
    }

    void save(Window im, string filename) {
        panic("This file type not implemented in this build\n");
    }

    void save(Window im, string filename, int opt) {
        panic("This file type not implemented in this build\n");
    }

    void save(Window im, string filename, string opt) {
        panic("This file type not implemented in this build\n");
    }
