addpath(fullfile(fileparts(mfilename('fullpath')), 'imagestack', 'matlab'));
