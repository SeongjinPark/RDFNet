function [HHA,pc2,HHB, AHB] = saveHHA(imName, C, outDir, D, RD,dataDir)
% function HHA = saveHHA(imName, C, outDir, D, RD)

% AUTORIGHTS

  if(isempty(D)), D = getImage(imName,dataDir, 'depth_org'); end
  if(isempty(RD)), RD = getImage(imName,dataDir, 'rawdepth_org'); end

  D = double(D)./1000; original 
%      D = bitor(bitshift(D,-3), bitshift(D,16-3));
%      D = single(D)/1000; 
%      D(D >8)=8;
% %   D= double(D)./1000; 
%     D = double(D);
  missingMask = RD == 0; % do not use inpainted data (original)
%     missingMask = RD > 1000000;  % use inpainted data (sj)

  
%   size(RD)
%   size(missingMask)
%   size(D)
%   imagesc(RD)
%   pause(0.01)
%   imagesc(missingMask)
%   pause
% %     figure(1000)
% %   imagesc(D)
%   pause
  
  [pc, N, yDir, h, pcRot, NRot] = processDepthImage(D*100, missingMask, C);
  angl = acosd(min(1,max(-1,sum(bsxfun(@times, N, reshape(yDir, 1, 1, 3)), 3))));  %original 
  angl_x = acosd(min(1,max(-1,sum(bsxfun(@times, NRot, reshape([1 0 0]', 1, 1, 3)), 3))));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  pc2 = pc;
  pc2(:,:,2) = -pc2(:,:,2);
  pc2(:,:,1) = pc2(:,:,1)-min(min(pc2(:,:,1)));
  pc2(:,:,2) = pc2(:,:,2)-min(min(pc2(:,:,2)));
  pc2(:,:,3) = pc2(:,:,3)-min(min(pc2(:,:,3)));
  pc2 = pc2 / max(max(max(pc2))) * 255;
  
%   x = reshape(pc(:,:,1),1,[]);
%   y = reshape(pc(:,:,2),1,[]);
%   z = reshape(pc(:,:,3),1,[]);
%   figure
%   scatter3(x(1:20:end),y(1:20:end),z(1:20:end),'.')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  

  % Making the minimum depth to be 100, to prevent large values for disparity!!!
%     figure(100);imagesc(pc(:,:,3));
%   pause
%   pc(:,:,3) = max(pc(:,:,3), 100); %original 
  pc(:,:,3) = max(pc(:,:,3), 80); 

%   figure(100);imagesc(pc(:,:,3));
%   pause
%   I(:,:,1) = 31000./pc(:,:,3); %original
  I(:,:,1) = 20400./pc(:,:,3); 
  
  I(:,:,2) = h;
  I(:,:,3) = (angl+128-90); %Keeping some slack
  
  HHB = I;
  HHB(:,:,3)=(angl_x+128-90);
  
  AHB = HHB;
  AHB(:,:,1)=(angl+128-90);
  
  
  I = uint8(I);
  HHB = uint8(HHB);
  AHB = uint8(AHB);
  
  % Save if can save
%   if(~isempty(outDir) && ~isempty(imName)), imwrite(I, fullfile_ext(outDir, imName, 'png')); end
  
  HHA = I;
end
